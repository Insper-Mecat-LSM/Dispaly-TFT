// *******************************Henrique************************************//
//  Programa Teste 1 - Criando Formas Geométricas 
//
// ************** Display TFT-  ILI9341  Retângulo*************************** \\


//************************ Biblioteca *****************************************//
#include "mbed.h"
#include "Arduino.h"
#include <MCUFRIEND_kbv.h>
MCUFRIEND_kbv tft;

//****************************************************************************//

//***********************Orientação  Display**********************************//


uint8_t Orientation = 1;  

//****************************************************************************//



//***********************Tabela de Cores**************************************//
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

//****************************************************************************//

//***********************Escrita no  Display**********************************//
void forma ()
{
   
    tft.drawRoundRect(60, 90, 190, 40, 1, WHITE); // (x,y,x1,y1,s)
    //tft.fillRoundRect(60, 90, 190, 40, 1, BLUE);
    tft.setTextColor(RED);
    tft.setTextSize(3);
    tft.setCursor(70, 98); // Orientação X,Y
    tft.println("RECTANGLE");


}

//****************************************************************************//



void setup(void)
{

    tft.reset();
    tft.begin();
    tft.setRotation(Orientation);
    tft.fillScreen(BLACK);  // Fundo do Display
    forma();
    delay(1000);
}

void loop()
{

}

