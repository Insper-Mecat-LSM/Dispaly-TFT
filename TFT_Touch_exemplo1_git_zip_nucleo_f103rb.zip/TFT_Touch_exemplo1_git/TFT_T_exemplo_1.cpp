// *******************************Henrique************************************//
//  Programa Teste 1 - Escrita no Display
//
// ************** Display TFT-  ILI9341  TS_1************** \\


//************************ Biblioteca *****************************************//
#include "mbed.h"
#include "Arduino.h"
#include <MCUFRIEND_kbv.h>
MCUFRIEND_kbv tft;

//****************************************************************************//

//***********************Orientação  Display**********************************//


uint8_t Orientation = 1;  

//****************************************************************************//



//***********************Tabela de Cores**************************************//
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

//****************************************************************************//

//***********************Escrita no  Display**********************************//
void write ()
{
    tft.setTextColor(BLUE);
    tft.setTextSize(3);     // Tamanho do Texto no Display
    tft.setCursor(60, 30); //  Orientação do texto X,Y
    tft.println("DISPLAY TFT");


}

//****************************************************************************//



void setup(void)
{

    tft.reset();
    tft.begin();
    tft.setRotation(Orientation);
    tft.fillScreen(WHITE);  // Fundo do Display
    write();
    delay(1000);
}

void loop()
{

}

