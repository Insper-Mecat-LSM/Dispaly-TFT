// should just use the virginal Adafruit_GFX v1.10.7
// only with #include "glcdfont.inc"

#ifndef _ADA_GFX_KBV_H
#define _ADA_GFX_KBV_H

#define ARDUINO 100
//#include "Arduino.h"
#define boolean bool

#include "Adafruit_GFX.h"

#endif // _ADA_GFX_KBV_H
